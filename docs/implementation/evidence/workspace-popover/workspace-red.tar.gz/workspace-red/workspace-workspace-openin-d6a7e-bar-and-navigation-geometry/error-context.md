# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workspace.spec.ts >> workspace opening preserves sidebar and navigation geometry
- Location: tests\theme-picker-browser\workspace.spec.ts:51:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "height": 460,
-   "nav": 166,
+   "height": 663,
+   "nav": 401,
    "width": 247,
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary "Platform workspace" [ref=e4]:
    - link "Cerebru — Overview" [ref=e5] [cursor=pointer]:
      - /url: /platform
      - generic [ref=e6]: C
      - generic [ref=e7]:
        - strong [ref=e8]: Cerebru
        - generic [ref=e9]: Assessment Training Tracker
    - group [ref=e10]:
      - generic "Workspace Platform administration" [active] [ref=e11] [cursor=pointer]:
        - generic [ref=e13]:
          - generic [ref=e14]: Workspace
          - strong [ref=e15]: Platform administration
      - navigation "Choose workspace" [ref=e16]:
        - link "Platform administration" [ref=e17] [cursor=pointer]:
          - /url: /platform
        - link "Learning workspace" [ref=e18] [cursor=pointer]:
          - /url: /dashboard
        - link "Choose your client" [ref=e19] [cursor=pointer]:
          - /url: /clients
        - link "Manage account access" [ref=e20] [cursor=pointer]:
          - /url: /accounts
        - link "Back to Cerebru" [ref=e21] [cursor=pointer]:
          - /url: https://opsbrain-eosin.vercel.app/home
    - paragraph [ref=e22]: Platform administration
    - navigation "Main navigation" [ref=e23]:
      - link "Overview" [ref=e24] [cursor=pointer]:
        - /url: /platform
      - link "Clients" [ref=e26] [cursor=pointer]:
        - /url: /platform/clients
      - link "People & access" [ref=e28] [cursor=pointer]:
        - /url: /platform/people
      - link "Audit log" [ref=e30] [cursor=pointer]:
        - /url: /platform/audit
      - link "Settings" [ref=e32] [cursor=pointer]:
        - /url: /platform/settings
    - generic [ref=e35]:
      - button "Theme Light" [ref=e37] [cursor=pointer]:
        - generic [ref=e38]: Theme
        - generic [ref=e39]: Light
      - status [ref=e40]
  - generic [ref=e41]:
    - banner [ref=e42]:
      - generic [ref=e43]: Platform administration
      - generic [ref=e44]:
        - button "Personal settings" [ref=e45] [cursor=pointer]: S
        - generic [ref=e46]:
          - strong [ref=e47]: Synthetic user
          - generic [ref=e48]: Global administration
        - button "Sign out" [ref=e49] [cursor=pointer]
    - main [ref=e50]:
      - heading "Theme picker fixture" [level=1] [ref=e51]
      - button "Outside action" [ref=e52] [cursor=pointer]
    - contentinfo [ref=e53]:
      - generic [ref=e54]: Assessment Training Tracker
      - generic [ref=e55]: Learning with purpose. Progress with evidence.
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { build } from 'esbuild';
  3  | import { themes } from '../../packages/domain/src/theme.js';
  4  | import AxeBuilder from '@axe-core/playwright';
  5  | import { readFile } from 'node:fs/promises';
  6  | 
  7  | // Production shell, picker and CSS; isolated synthetic transport, no app/database.
  8  | let bundle: string, css: string;
  9  | test.beforeAll(async () => {
  10 |   const output = await build({
  11 |     stdin: {
  12 |       contents: `import {createRoot} from 'react-dom/client';
  13 |         import {useState,useEffect} from 'react';
  14 |         import {ApplicationShell} from './apps/web/app/components/application-shell';
  15 |         import {themes} from './packages/domain/src/theme';
  16 |         function Fixture(){
  17 |           const [selected,setSelected]=useState(localStorage.getItem('theme-test')||'light');
  18 |           useEffect(()=>{const refresh=()=>setSelected(localStorage.getItem('theme-test')||'light');window.addEventListener('brandingchanged',refresh);return()=>window.removeEventListener('brandingchanged',refresh)},[]);
  19 |           useEffect(()=>{document.documentElement.dataset.theme=selected},[selected]);
  20 |           return <ApplicationShell themeClientId={location.search.includes('client')?'synthetic-client':undefined} context={{user:{global_admin:!location.search.includes('member')},canAdmin:location.search.includes('admin'),csrf:'synthetic'}} pathname='/platform' platform activePage='overview' navigationBusy={false} name='Synthetic user' brand={{displayName:'Scalyn',appName:'Assessment Training Tracker',mode:location.search.includes('white')?'white-label':'cerebru',selectedTheme:selected,logo:null,palettes:{},platformPalettes:{},themes}} storageKey='theme-test' reload={()=>{}} logout={()=>{}} signingOut={false}><h1>Theme picker fixture</h1><button>Outside action</button></ApplicationShell>
  21 |         }createRoot(document.getElementById('root')).render(<Fixture/>);`,
  22 |       resolveDir: process.cwd(),
  23 |       loader: 'tsx',
  24 |     },
  25 |     bundle: true,
  26 |     write: false,
  27 |     outdir: '.runtime/theme-picker-bundle',
  28 |     platform: 'browser',
  29 |     jsx: 'automatic',
  30 |     define: { 'process.env.NODE_ENV': '"production"', 'process.env': '{}' },
  31 |   });
  32 |   bundle = output.outputFiles.find((file) => file.path.endsWith('.js'))!.text;
  33 |   css = await readFile('apps/web/app/globals.css', 'utf8');
  34 |   css += output.outputFiles
  35 |     .filter((file) => file.path.endsWith('.css'))
  36 |     .map((file) => file.text)
  37 |     .join('\n');
  38 | });
  39 | async function mount(page: Page, query = '') {
  40 |   await page.route('http://theme.invalid/**', (route) =>
  41 |     route.fulfill({
  42 |       contentType: 'text/html',
  43 |       body: '<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>Theme fixture</title></head><body><div id="root"></div></body></html>',
  44 |     }),
  45 |   );
  46 |   await page.goto('http://theme.invalid/' + query);
  47 |   await page.addStyleTag({ content: css });
  48 |   await page.addScriptTag({ content: bundle });
  49 | }
  50 | 
  51 | test('workspace opening preserves sidebar and navigation geometry', async ({page}, info) => {
  52 |   await page.setViewportSize({width:1280,height:460});
  53 |   await mount(page);
  54 |   const sidebar=page.getByRole('complementary');
  55 |   const geometry=()=>sidebar.evaluate(el=>({height:el.scrollHeight,width:el.scrollWidth,nav:el.querySelector('[aria-label="Main navigation"]')!.getBoundingClientRect().y}));
  56 |   const before=await geometry();
  57 |   await sidebar.locator('summary,button').filter({hasText:'Workspace'}).first().click();
  58 |   await expect(page.getByRole('navigation',{name:'Choose workspace'})).toBeVisible();
  59 |   await page.screenshot({path:info.outputPath('workspace.png')});
> 60 |   expect(await geometry()).toEqual(before);
     |                            ^ Error: expect(received).toEqual(expected) // deep equality
  61 | });
  62 | 
```