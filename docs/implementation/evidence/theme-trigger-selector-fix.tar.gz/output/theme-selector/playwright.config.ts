import { defineConfig } from '@playwright/test';
import base from '../../playwright.guest-ui.config';
export default defineConfig({ ...base, testDir: '../../tests/guest-ui-browser', reporter: 'list', outputDir: './results', use: { ...base.use, baseURL: 'http://127.0.0.1:3400' }, webServer: { ...base.webServer, cwd: process.cwd(), command: 'tsx output/theme-selector/start.ts', url: 'http://127.0.0.1:3400/api/health/ready', reuseExistingServer: false } });
