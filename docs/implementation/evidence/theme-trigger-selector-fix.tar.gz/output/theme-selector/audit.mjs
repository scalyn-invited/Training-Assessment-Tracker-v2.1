import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
const files=execFileSync('git',['diff','--name-only','--','tests'],{encoding:'utf8'}).trim().split('\n');
let count=0;
for(const p of files){
 const old=execFileSync('git',['show','HEAD:'+p],{encoding:'utf8'});
 count+=old.split('/^Theme /').length-1;
 if(!p.includes('guest-ui-browser') && old.replaceAll('/^Theme /','/^Theme(?: |$)/')!==readFileSync(p,'utf8')) throw Error(p+' has unrelated edits');
}
console.log(JSON.stringify({files:files.length, originalSelectors:count, nonGuestChanges:'selector-only'}));
