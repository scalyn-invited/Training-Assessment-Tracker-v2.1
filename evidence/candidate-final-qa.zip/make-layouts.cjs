const fs=require('node:fs');let s=fs.readFileSync('tests/expanded-appearance-browser/scope.spec.ts','utf8');s=s.slice(0,s.indexOf('  await page.addInitScript(() => {'));s=s.replace('real API scoped navigation never renders target content in the previous scope theme','shared and distinct static layouts retain Dark and heading geometry on throttled responsive reload').replace("const dir = process.env.QA_EVIDENCE_DIR || 'evidence/expanded';","const dir = process.env.QA_EVIDENCE_DIR || 'evidence/candidate-final/layouts';");s+=`
  for(const url of ['/platform','/dashboard']) {
    await page.goto(url);
    await expect(page.locator('main h1')).toBeVisible();
    const menu=page.locator('summary:visible').filter({hasText:'Theme'}).first();
    await menu.click();
    const saved=page.waitForResponse(r=>r.url().includes('/api/branding/preference')&&r.request().method()==='POST');
    await page.getByRole('button',{name:'Dark',exact:true}).click();
    expect((await saved).ok()).toBe(true);
    await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  }
  await page.addInitScript(()=>{
    const w=window as any;w.__layoutFrames=[];
    const tick=()=>{if(document.body){const h=document.querySelector('main h1'),r=h?.getBoundingClientRect();
      w.__layoutFrames.push({theme:document.documentElement.dataset.theme,heading:h?.textContent,rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null,font:h?getComputedStyle(h).font:null,pending:!!document.querySelector('[data-appearance-pending]'),width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth});}
      requestAnimationFrame(tick);};requestAnimationFrame(tick);
  });
  await page.route('**/api/**',async route=>{await new Promise(r=>setTimeout(r,200));await route.continue();});
  const results:any[]=[];
  const urls=['/platform','/platform/clients','/platform/people','/platform/audit','/platform/settings','/platform/settings/status','/accounts','/account/security','/clients','/dashboard','/people','/administration','/settings/ai','/settings/appearance','/enrolments','/assessments','/notifications','/learning-reviews'];
  for(const width of [1440,820,390]){
    await page.setViewportSize({width,height:1000});
    for(const url of urls){
      await page.goto(url);
      await expect(page.locator('main h1').first()).toBeVisible();
      await page.waitForTimeout(400);
      const frames=await page.evaluate(()=>(window as any).__layoutFrames);
      const last=frames.at(-1);
      const matching=frames.filter((f:any)=>f.heading===last.heading&&f.rect&&f.rect.width>0);
      const badThemes=frames.filter((f:any)=>f.theme!=='dark');
      const geometry=matching.filter((f:any)=>Object.keys(last.rect).some(k=>Math.abs(f.rect[k]-last.rect[k])>1)||f.font!==last.font);
      const result={url,width,samples:frames.length,heading:last.heading,badThemes,geometry,overflow:frames.filter((f:any)=>f.overflow>1)};
      results.push(result);
      await writeFile(dir+'/summary.json',JSON.stringify(results,null,2));
      await writeFile(dir+'/'+url.replaceAll('/','_')+'-'+width+'.json',JSON.stringify(frames,null,2));
      expect.soft(badThemes,url+' '+width+' immediate Dark').toEqual([]);
      expect.soft(geometry,url+' '+width+' existing heading geometry').toEqual([]);
      expect.soft(result.overflow,url+' '+width+' no horizontal overflow').toEqual([]);
      if(['/platform','/dashboard','/platform/clients','/settings/ai'].includes(url)) await page.screenshot({path:dir+'/'+url.replaceAll('/','_')+'-'+width+'.png',fullPage:false});
    }
  }
});
`;fs.writeFileSync('tests/expanded-appearance-browser/layouts.spec.ts',s);