const fs=require('node:fs');let s=fs.readFileSync('tests/expanded-appearance-browser/css-gate.spec.ts','utf8');s=s.slice(0,s.indexOf('  let release!:()=>void; const held='));s=s.replace("destination remains styled while route CSS is delayed","screenshot observer calibration on settled dashboard").replace("'evidence/candidate-final/css'","'evidence/candidate-final/screenshot-calibration'");s=s.replace('t: performance.now(),','t: performance.now(), viewport: {w:innerWidth,h:innerHeight},');s+=`
  await page.locator('summary').filter({hasText:'Workspace'}).click();
  await page.getByRole('link',{name:'Learning workspace',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Welcome back, Scope QA owner.',exact:true})).toBeVisible();
  const phases:any[]=[];
  for(const phase of ['idle','screenshots']) {
    await page.evaluate(()=>{(window as any).__frames=[];});
    if(phase==='idle') await page.waitForTimeout(3000);
    else for(let i=0;i<20;i++) await page.screenshot({path:dir+'/capture-'+i+'.png',fullPage:true});
    const frames=await page.evaluate(()=>(window as any).__frames);
    phases.push({phase,frames});
  }
  await writeFile(dir+'/phases.json',JSON.stringify(phases,null,2));
  expect(phases[0].frames.filter((f:any)=>f.rect?.width<400)).toEqual([]);
});
`;fs.writeFileSync('tests/expanded-appearance-browser/screenshot-calibration.spec.ts',s);