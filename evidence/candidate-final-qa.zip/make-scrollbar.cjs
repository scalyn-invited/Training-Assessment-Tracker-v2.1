const fs=require('node:fs');let s=fs.readFileSync('tests/expanded-appearance-browser/layouts.spec.ts','utf8');s=s.slice(0,s.indexOf('  await page.addInitScript(()=>{'));s=s.replace('shared and distinct static layouts retain Dark and heading geometry on throttled responsive reload','tablet directory loading preserves existing action positions').replace("'evidence/candidate-final/layouts'","'evidence/candidate-final/scrollbar'");s+=`
  await page.setViewportSize({width:820,height:1000});
  let release!:()=>void;const held=new Promise<void>(r=>release=r);
  let seen!:()=>void;const requested=new Promise<void>(r=>seen=r);
  await page.route('**/api/platform/clients?*',async route=>{seen();await held;await route.continue();});
  await page.goto('/platform/clients');await requested;
  await expect(page.getByRole('heading',{name:'Clients',exact:true})).toBeVisible();
  const capture=()=>page.evaluate(()=>({width:innerWidth,clientWidth:document.documentElement.clientWidth,theme:document.documentElement.dataset.theme,elements:[...document.querySelectorAll('main h1,main button,main input')].filter((e:any)=>e.getBoundingClientRect().width>0).map((e:any)=>{const r=e.getBoundingClientRect();return {tag:e.tagName,text:e.innerText||e.getAttribute('aria-label')||e.placeholder,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};})}));
  const pending=await capture();await page.screenshot({path:dir+'/pending.png'});
  release();await expect(page.getByText('Demo Client 1',{exact:true}).first()).toBeVisible();
  await page.waitForTimeout(200);
  const settled=await capture();await page.screenshot({path:dir+'/settled.png'});
  const moved=pending.elements.flatMap((p:any)=>{const q=settled.elements.find((q:any)=>q.tag===p.tag&&q.text===p.text);return q&&(Math.abs(p.rect.x-q.rect.x)>1||Math.abs(p.rect.y-q.rect.y)>1)?[{before:p,after:q}]:[];});
  await writeFile(dir+'/geometry.json',JSON.stringify({pending,settled,moved},null,2));
  expect(moved,'existing visible controls must not jump when data arrives').toEqual([]);
});
`;fs.writeFileSync('tests/expanded-appearance-browser/scrollbar.spec.ts',s);