# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scope.spec.ts >> real API scoped navigation never renders target content in the previous scope theme
- Location: tests\expanded-appearance-browser\scope.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-appearance-pending]')
Expected: visible
Timeout: 1000ms
Error: element(s) not found

Call log:
  - Expect "soft toBeVisible" locator('[data-appearance-pending]') with timeout 1000ms
  - waiting for locator('[data-appearance-pending]')

```

```yaml
- link "Skip to content":
  - /url: "#main"
- alert
- complementary "Learning workspace":
  - link "QA Alpha — Overview":
    - /url: /dashboard
    - text: Q
    - strong: QA Alpha
    - text: Scope QA
  - group:
    - text: Workspace
    - strong: Learning workspace
  - paragraph: Learning workspace
  - navigation "Main navigation":
    - link "Platform administration":
      - /url: /platform
    - link "Overview":
      - /url: /dashboard
    - link "Learning plans":
      - /url: /dashboard#learning-plans
    - link "Assessments":
      - /url: /assessments
    - link "Updates":
      - /url: /notifications
    - link "People":
      - /url: /people
    - link "Administration":
      - /url: /administration
    - link "Account access":
      - /url: /accounts
    - link "AI settings":
      - /url: /settings/ai
    - link "Appearance":
      - /url: /settings/appearance
    - link "Account security":
      - /url: /account/security
  - group: Theme Client Dark
  - status
- banner:
  - text: Local sandbox Synthetic people · Local password sign-in · No email delivery
  - button "Personal settings": S
  - strong: Scope QA owner
  - text: Current client access
  - button "Sign out"
- form "Active client":
  - text: Active client
  - combobox "Active client":
    - option "Choose client"
    - option "Demo Client 1" [selected]
    - option "Demo Client 2"
    - option "Demo Client 3"
  - button "Switch client"
- main:
  - paragraph: Your development space
  - heading "Welcome back, Scope QA owner." [level=1]
  - paragraph: A little focus today. A meaningful step forward.
  - text: Signed in
  - region "Your next chapter starts with a baseline.":
    - paragraph: The big picture
    - heading "Your next chapter starts with a baseline." [level=2]
    - paragraph: Understand your starting point, practise with purpose, and make your progress visible.
  - region "Your account":
    - heading "Your account" [level=2]
    - text: Client workspace
    - term: Name
    - definition: Scope QA owner
    - term: Access
    - definition: Scoped to the selected client
    - term: Learning plans
    - definition: 0 plans
    - term: Workspace scope
    - definition: Programmes in your scope
    - link "View learning plans":
      - /url: "#learning-plans"
  - region "A focused journey":
    - heading "A focused journey" [level=2]
    - text: 01 / 03
    - list:
      - listitem:
        - text: "01"
        - heading "Know your starting point" [level=3]
        - paragraph: Capture a baseline for your chosen skills.
      - listitem:
        - text: "02"
        - heading "Put learning into practice" [level=3]
        - paragraph: Turn weekly objectives into evidence.
      - listitem:
        - text: "03"
        - heading "Reflect on your growth" [level=3]
        - paragraph: Review your progress with approved evidence.
  - heading "Training plans in your scope" [level=2]
  - text: 0 plans
  - heading "No enrolments available" [level=3]
  - paragraph: No training plans are currently available to you in this client. Contact your client administrator if you expected access.
  - paragraph:
    - link "Training records":
      - /url: /enrolments
  - region "Background check receipts":
    - heading "Background receipts" [level=2]
    - text: Refreshes every 5 seconds
    - paragraph: Local notification sink. No outbound email.
    - list:
      - listitem: No checks requested yet. Open a training record to check background processing.
- contentinfo: Scope QA Learning with purpose. Progress with evidence.
```

# Test source

```ts
  180 |     expect(
  181 |       samples.filter(
  182 |         (f: any) => f.path === (shared ? '/platform' : '/dashboard') && !f.shell && !f.pending,
  183 |       ),
  184 |     ).toEqual([]);
  185 |     await page.unroute(pattern);
  186 |   };
  187 |   await transition(
  188 |     'reverse-failure-retry',
  189 |     true,
  190 |     () => page.getByRole('link', { name: 'Platform administration', exact: true }).first().click(),
  191 |     true,
  192 |   );
  193 |   await transition('history-back-client', false, () => page.goBack());
  194 |   await transition('history-forward-platform', true, () => page.goForward());
  195 |   await transition('history-back-client-again', false, () => page.goBack());
  196 |   // Capture an old real response, then deliver it after a newer generation.
  197 |   const pattern = '**/api/branding/current?shared=0';
  198 |   let oldRelease!: () => void, oldSeen!: () => void;
  199 |   const oldGate = new Promise<void>((r) => (oldRelease = r));
  200 |   const oldRequest = new Promise<void>((r) => (oldSeen = r));
  201 |   await page.evaluate(() => ((window as any).__frames = []));
  202 |   let count = 0;
  203 |   await page.route(pattern, async (route) => {
  204 |     if (++count === 1) {
  205 |       const response = await route.fetch();
  206 |       const data = await response.json();
  207 |       oldSeen();
  208 |       await oldGate;
  209 |       await route.fulfill({
  210 |         json: { ...data, displayName: 'OBSOLETE RESPONSE', selectedTheme: 'light' },
  211 |       });
  212 |     } else await route.continue();
  213 |   });
  214 |   await page.evaluate(() => window.dispatchEvent(new Event('brandingchanged')));
  215 |   await oldRequest;
  216 |   const newer = page.waitForResponse((r) => r.url().includes('/branding/current?shared=0'));
  217 |   await page.evaluate(() => window.dispatchEvent(new Event('brandingchanged')));
  218 |   await newer;
  219 |   oldRelease();
  220 |   await page.waitForTimeout(200);
  221 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'client-dark');
  222 |   await expect(page.getByText('OBSOLETE RESPONSE')).toHaveCount(0);
  223 |   const reordered = await page.evaluate(() => (window as any).__frames);
  224 |   await writeFile(dir + '/out-of-order-frames.json', JSON.stringify(reordered, null, 2));
  225 |   expect(reordered.filter((f: any) => f.heading === 'Welcome back, Scope QA owner.' &&
  226 |     (f.theme !== 'client-dark' || !f.text.includes('QA Alpha') || f.text.includes('OBSOLETE RESPONSE')))).toEqual([]);
  227 |   await page.unroute(pattern);
  228 |   // An obsolete response from a departed scope cannot write the document either.
  229 |   let departedRelease!: () => void, departedSeen!: () => void;
  230 |   const departedGate = new Promise<void>((r) => (departedRelease = r));
  231 |   const departedRequest = new Promise<void>((r) => (departedSeen = r));
  232 |   await page.route(pattern, async (route) => {
  233 |     const response = await route.fetch();
  234 |     departedSeen();
  235 |     await departedGate;
  236 |     await route.fulfill({ response });
  237 |   });
  238 |   await page.evaluate(() => window.dispatchEvent(new Event('brandingchanged')));
  239 |   await departedRequest;
  240 |   await transition('departed-response-platform', true, () => page.goForward());
  241 |   departedRelease();
  242 |   await page.waitForTimeout(200);
  243 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  244 |   await expect(page.getByRole('heading', { name: 'Platform overview', exact: true })).toBeVisible();
  245 |   const departed = await page.evaluate(() => (window as any).__frames);
  246 |   expect(departed.filter((f: any) => f.heading === 'Platform overview' &&
  247 |     (f.theme !== 'light' || !f.text.includes('Scalyn')))).toEqual([]);
  248 |   await writeFile(
  249 |     dir + '/stale-response-frames.json',
  250 |     JSON.stringify(departed, null, 2),
  251 |   );
  252 |   await page.unroute(pattern);
  253 |   await transition('return-after-stale-response', false, () => page.goBack());
  254 |   // Exercise a reused shell as well as document navigation: A -> B -> A must
  255 |   // resolve a new authority generation even though A's key appeared previously.
  256 |   let releaseB!: () => void, releaseA!: () => void;
  257 |   let seenB!: () => void, seenA!: () => void;
  258 |   const gateB = new Promise<void>(r => releaseB = r);
  259 |   const gateA = new Promise<void>(r => releaseA = r);
  260 |   const requestB = new Promise<void>(r => seenB = r);
  261 |   const requestA = new Promise<void>(r => seenA = r);
  262 |   let switched = 0;
  263 |   await page.route(pattern, async route => {
  264 |     const index = ++switched;
  265 |     const response = await route.fetch();
  266 |     if (index === 1) { seenB(); await gateB; }
  267 |     else { seenA(); await gateA; }
  268 |     await route.fulfill({ response });
  269 |   });
  270 |   const publishClient = async (id: string) => {
  271 |     await post('/clients/select', { clientId: id });
  272 |     const context = await (await page.request.get('/api/auth/context')).json();
  273 |     await page.evaluate(context => window.dispatchEvent(new CustomEvent('trackercontext', { detail: context })), context);
  274 |   };
  275 |   await publishClient(b.id);
  276 |   await requestB;
  277 |   await expect(page.locator('[data-appearance-pending]')).toBeVisible();
  278 |   await publishClient(a.id);
  279 |   await requestA;
> 280 |   await expect.soft(page.locator('[data-appearance-pending]')).toBeVisible({ timeout: 1000 });
      |                                                                ^ Error: expect(locator).toBeVisible() failed
  281 |   releaseA();
  282 |   await expect(page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true })).toBeVisible();
  283 |   releaseB();
  284 |   await page.waitForTimeout(200);
  285 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'client-dark');
  286 |   await expect(page.locator('[data-application-shell]')).toContainText('QA Alpha');
  287 |   await page.unroute(pattern);
  288 |   // Full document client switches: verify selected authority and pre-hydration frame themes.
  289 |   await page.getByRole('combobox', { name: 'Active client', exact: true }).selectOption(b.id);
  290 |   await page.getByRole('button', { name: 'Switch client', exact: true }).click();
  291 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'client-light');
  292 |   await expect(
  293 |     page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true }),
  294 |   ).toBeVisible();
  295 |   const ctx = await (await page.request.get('/api/auth/context')).json();
  296 |   expect(ctx.client.id).toBe(b.id);
  297 |   const bFrames = await page.evaluate(() => (window as any).__frames);
  298 |   await writeFile(dir + '/client-b-frames.json', JSON.stringify(bFrames, null, 2));
  299 |   expect(bFrames.filter((f: any) => f.theme !== 'client-light')).toEqual([]);
  300 |   expect(
  301 |     bFrames.filter(
  302 |       (f: any) => f.heading === 'Welcome back, Scope QA owner.' && !f.text.includes('QA Beta'),
  303 |     ),
  304 |   ).toEqual([]);
  305 |   await page.reload();
  306 |   await expect(
  307 |     page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true }),
  308 |   ).toBeVisible();
  309 |   const reloadFrames = await page.evaluate(() => (window as any).__frames);
  310 |   await writeFile(dir + '/client-b-reload-frames.json', JSON.stringify(reloadFrames, null, 2));
  311 |   expect(reloadFrames.filter((f: any) => f.theme !== 'client-light')).toEqual([]);
  312 |   for (const width of [800, 390]) {
  313 |     await page.setViewportSize({ width, height: 900 });
  314 |     await page.reload();
  315 |     await expect(
  316 |       page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true }),
  317 |     ).toBeVisible();
  318 |     const responsive = await page.evaluate(() => (window as any).__frames);
  319 |     await writeFile(
  320 |       dir + '/client-b-' + width + '-frames.json',
  321 |       JSON.stringify(responsive, null, 2),
  322 |     );
  323 |     expect(responsive.filter((f: any) => f.theme !== 'client-light')).toEqual([]);
  324 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  325 |       true,
  326 |     );
  327 |     await page.screenshot({ path: dir + '/client-b-' + width + '.png', fullPage: true });
  328 |   }
  329 |   await page.setViewportSize({ width: 1440, height: 900 });
  330 |   const owner = (await (await page.request.get('/api/auth/context')).json()).user;
  331 |   await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  332 |   await expect(page).toHaveURL(/\/login$/);
  333 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  334 |   await page.getByLabel('Email', { exact: true }).fill('demo.1.3@example.invalid');
  335 |   await page.getByLabel('Password', { exact: true }).fill('Isolated scope demo passphrase');
  336 |   await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  337 |   await expect(page).toHaveURL(/\/clients$/);
  338 |   const member = (await (await page.request.get('/api/auth/context')).json()).user;
  339 |   expect(member.id).not.toBe(owner.id);
  340 |   await page.locator('summary:visible').filter({ hasText: 'Theme' }).click();
  341 |   await page.getByRole('button', { name: 'Dark', exact: true }).click();
  342 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  343 |   await page.reload();
  344 |   await expect(
  345 |     page.getByRole('heading', { name: 'Choose your client', exact: true }),
  346 |   ).toBeVisible();
  347 |   const memberFrames = await page.evaluate(() => (window as any).__frames);
  348 |   await writeFile(dir + '/member-dark-reload-frames.json', JSON.stringify(memberFrames, null, 2));
  349 |   expect(memberFrames.filter((f: any) => f.theme !== 'dark')).toEqual([]);
  350 |   await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  351 |   await expect(page).toHaveURL(/\/login$/);
  352 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  353 |   await page.getByLabel('Email', { exact: true }).fill('scope-qa@example.invalid');
  354 |   await page.getByLabel('Password', { exact: true }).fill('Isolated scope QA passphrase');
  355 |   await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  356 |   await expect(page.getByRole('heading', { name: 'Platform overview', exact: true })).toBeVisible();
  357 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  358 |   const saved = await page.evaluate(() =>
  359 |     Object.fromEntries(
  360 |       Object.entries(localStorage).filter(([k]) => k.startsWith('training.v21.appearance.')),
  361 |     ),
  362 |   );
  363 |   expect(saved['training.v21.appearance.platform.' + owner.environment + '.' + owner.id]).toBe(
  364 |     'light',
  365 |   );
  366 |   expect(saved['training.v21.appearance.platform.' + member.environment + '.' + member.id]).toBe(
  367 |     'dark',
  368 |   );
  369 |   await writeFile(
  370 |     dir + '/identity-summary.json',
  371 |     JSON.stringify(
  372 |       {
  373 |         distinctUsers: owner.id !== member.id,
  374 |         ownerPreference: 'light',
  375 |         memberPreference: 'dark',
  376 |         guestTheme: 'light',
  377 |         ownerReturnTheme: 'light',
  378 |       },
  379 |       null,
  380 |       2,
```