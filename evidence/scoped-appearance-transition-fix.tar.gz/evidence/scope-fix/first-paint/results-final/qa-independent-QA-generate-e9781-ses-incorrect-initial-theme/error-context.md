# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa-independent.spec.ts >> QA generated preference outage exposes incorrect initial theme
- Location: tests\first-paint-browser\qa-independent.spec.ts:34:1

# Error details

```
Error: Saved generated Dark must not show Light on failure

expect(received).toBe(expected) // Object.is equality

Expected: "platform-dark"
Received: "dark"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=e3]:
    - banner [ref=e4]:
      - link "Scalyn Assessment Training Tracker" [ref=e5] [cursor=pointer]:
        - /url: /login
        - generic [ref=e6]:
          - strong [ref=e7]: Scalyn
          - generic [ref=e8]: Assessment Training Tracker
      - generic [ref=e9]:
        - paragraph [ref=e10]: Learning with purpose.
        - paragraph [ref=e11]: Progress with evidence.
        - generic [ref=e12]: Sign in to continue to your workspace.
    - generic [ref=e13]:
      - generic [ref=e15]:
        - group [ref=e16]:
          - generic "Theme Platform Dark" [ref=e17] [cursor=pointer]:
            - generic [ref=e20]: Theme
            - generic [ref=e21]: Platform Dark
        - status [ref=e22]
      - main [ref=e23]:
        - generic [ref=e24]:
          - generic [ref=e25]:
            - heading "Sign in" [level=1] [ref=e26]
            - paragraph [ref=e27]: Welcome back. Enter your details to continue.
          - generic [ref=e28]:
            - generic [ref=e29]:
              - generic [ref=e30]: Email
              - textbox "Email" [ref=e32]:
                - /placeholder: name@company.com
            - generic [ref=e33]:
              - generic [ref=e34]: Password
              - textbox "Password" [ref=e36]
              - button "Show password" [ref=e37] [cursor=pointer]
            - group [ref=e38]:
              - generic "Forgot password?" [ref=e39] [cursor=pointer]
            - generic [ref=e40]:
              - button "Sign in" [ref=e41] [cursor=pointer]
              - paragraph [ref=e42]: No account yet? Ask your administrator to invite you.
              - paragraph [ref=e43]: If you received a client invitation, sign in first, then reopen the invitation link.
      - contentinfo [ref=e44]: Assessment Training Tracker
  - alert [ref=e45]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {writeFile} from 'node:fs/promises';
  3  | import AxeBuilder from '@axe-core/playwright';
  4  | 
  5  | test('QA baseline reload matrix and route continuity',async({page,context},info)=>{
  6  |  test.setTimeout(240000);
  7  |  const errors:string[]=[]; page.on('pageerror',e=>errors.push(e.message));
  8  |  page.on('console',m=>{if(m.type()==='error' && /hydration|did not match/i.test(m.text()))errors.push(m.text());});
  9  |  await page.addInitScript(()=>{
  10 |  const w=window as any;w.framesQA=[];w.shiftsQA=[];
  11 |  new PerformanceObserver(list=>{for(const e of list.getEntries())w.shiftsQA.push(JSON.parse(JSON.stringify(e)));}).observe({type:'layout-shift',buffered:true});
  12 |  const sample=()=>{if(document.body && document.querySelector('main'))w.framesQA.push({at:performance.now(),visibility:document.visibilityState,theme:document.documentElement.dataset.theme,canvas:getComputedStyle(document.body).backgroundColor,header:document.querySelector('header')?.getBoundingClientRect().toJSON()});requestAnimationFrame(sample);};requestAnimationFrame(sample);
  13 |  });
  14 |  await page.goto('/login');await page.bringToFront();
  15 |  await page.locator('summary').filter({hasText:'Theme'}).click();await page.getByRole('button',{name:'Dark',exact:true}).click();
  16 |  const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');
  17 |  const results=[];
  18 |  for(const [name,hard,cold,slow] of [['normal-warm',false,false,false],['hard-warm',true,false,false],['normal-cold',false,true,false],['hard-cold-800ms',true,true,true]] as const){
  19 |  if(cold)await cdp.send('Network.clearBrowserCache');
  20 |  await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:slow?800:0,downloadThroughput:slow?200000:-1,uploadThroughput:slow?100000:-1});
  21 |  const nav=page.waitForEvent('domcontentloaded');await cdp.send('Page.reload',{ignoreCache:hard});await nav;
  22 |  await page.screenshot({path:info.outputPath(name+'-intermediate.png')});
  23 |  await expect(page.getByLabel('Email',{exact:true})).toBeVisible();await expect(page.locator('.theme-current')).toHaveText('Dark');
  24 |  await page.screenshot({path:info.outputPath(name+'-settled.png')});
  25 |  const result=await page.evaluate(()=>({frames:(window as any).framesQA,shifts:(window as any).shiftsQA,preference:localStorage.getItem('training.v21.appearance.platform.guest')}));
  26 |  results.push({name,...result});
  27 |  expect(result.frames.length).toBeGreaterThan(0);expect([...new Set(result.frames.map((f:any)=>f.theme))]).toEqual(['dark']);expect([...new Set(result.frames.map((f:any)=>f.canvas))]).toEqual(['rgb(7, 11, 22)']);expect(result.preference).toBe('dark');
  28 |  }
  29 |  await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:0,downloadThroughput:-1,uploadThroughput:-1});
  30 |  for(const route of ['/account/link','/dashboard','/assessments','/qa-no-such-route']){await page.goto(route);await expect(page.locator('main')).toBeVisible();await expect(page.locator('html')).toHaveAttribute('data-theme','dark');results.push({route,...await page.evaluate(()=>({frames:(window as any).framesQA,shifts:(window as any).shiftsQA}))});}
  31 |  await writeFile(info.outputPath('matrix.json'),JSON.stringify({browser:context.browser()?.version(),results,errors},null,2));expect(errors).toEqual([]);
  32 | });
  33 | 
  34 | test('QA generated preference outage exposes incorrect initial theme',async({page,context},info)=>{
  35 |  await context.addCookies([{name:'brand-failure',value:'1',url:'http://127.0.0.1:3280'}]);
  36 |  await page.addInitScript(()=>localStorage.setItem('training.v21.appearance.platform.guest','platform-dark'));
  37 |  await page.goto('/login');await expect(page.getByRole('button',{name:'Retry appearance',exact:true})).toBeVisible();
  38 |  const before=await page.locator('html').getAttribute('data-theme');await page.screenshot({path:info.outputPath('outage.png')});
  39 |  await context.clearCookies();await page.getByRole('button',{name:'Retry appearance',exact:true}).click();await expect(page.locator('html')).toHaveAttribute('data-theme','platform-dark');await page.screenshot({path:info.outputPath('recovered.png')});
  40 |  await writeFile(info.outputPath('outage.json'),JSON.stringify({before,after:await page.locator('html').getAttribute('data-theme')}));
> 41 |  expect(before,'Saved generated Dark must not show Light on failure').toBe('platform-dark');
     |                                                                       ^ Error: Saved generated Dark must not show Light on failure
  42 | });
  43 | 
  44 | test('QA built-in readability keyboard reduced motion and retained input',async({page},info)=>{
  45 |  await page.emulateMedia({reducedMotion:'reduce',colorScheme:'dark'});await page.goto('/login');await page.getByLabel('Email',{exact:true}).fill('synthetic@example.invalid');
  46 |  const findings=[];
  47 |  for(const theme of ['Dark','Light','Neon Cyan','Neon Emerald','Neon Amber']){
  48 |  await page.locator('summary').filter({hasText:'Theme'}).click();await page.getByRole('button',{name:theme,exact:true}).click();
  49 |  await expect(page.getByLabel('Email',{exact:true})).toHaveValue('synthetic@example.invalid');
  50 |  const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','wcag22aa']).analyze();findings.push({theme,violations:axe.violations});
  51 |  await page.getByLabel('Email',{exact:true}).focus();await page.keyboard.press('Tab');expect(await page.evaluate(()=>document.activeElement?.tagName)).toBe('INPUT');
  52 |  }
  53 |  await writeFile(info.outputPath('accessibility.json'),JSON.stringify(findings,null,2));expect(findings.flatMap(f=>f.violations)).toEqual([]);
  54 | });
  55 | 
```