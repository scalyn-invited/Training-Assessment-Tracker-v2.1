const fs=require('fs');
let b=fs.readFileSync('tests/expanded-appearance-browser/builder-gate.spec.ts','utf8').split('  let release!:')[0];
b=b.replace("import { test, expect } from '@playwright/test';","import { test, expect } from '@playwright/test';\nimport {install,start,finish} from './temporal-helper';");
b=b.replace("test('FOUC-QA-05 builder mounts after delayed appearance authority'","test('responsive editor controls through authority and section transitions'");
b+=`
 await page.goto('/assessments');
 await page.locator('summary:visible').filter({hasText:'Theme'}).click();
 const saved=page.waitForResponse(r=>r.url().includes('/api/branding/preference')&&r.request().method()==='POST');
 await page.getByRole('button',{name:'Dark',exact:true}).click();await saved;
 await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
 await install(page);
 for(const width of [1440,820,390]){
   await page.setViewportSize({width,height:1000});
   let open!:()=>void;const gate=new Promise<void>(r=>open=r);let seen=false;
   await page.route('**/api/branding/current?*',async r=>{seen=true;await gate;await r.continue();});
   await page.goto('/assessments/definitions/new');await expect.poll(()=>seen).toBe(true);
   await expect(page.getByText('Opening workspace',{exact:true})).toBeVisible();
   await start(page,{title:'#assessment-title',save:'#save-draft',nav:'[data-section="questions"]'},'authority-pending-ready');
   open();await expect(page.getByLabel('Assessment title',{exact:true})).toBeVisible();
   // Mark by accessible control rather than assume a generated ID.
   await page.getByRole('button',{name:'Save draft',exact:true}).evaluate(e=>e.setAttribute('data-qa-save',''));
   await finish(page,'editor-ready-'+width,['title','nav']);await page.unroute('**/api/branding/current?*');
   await start(page,{nav:'[data-section="questions"]',save:'[data-qa-save]'},'section-switch');
   await page.locator('[data-section="questions"]').click();
   await expect(page.getByTestId('prompt-editor').first()).toBeVisible();
   await finish(page,'editor-questions-'+width,['nav']);
   await start(page,{prompt:'[data-testid="prompt-editor"]',nav:'[data-section="questions"]'},'question-input');
   await page.getByTestId('prompt-editor').first().fill('Temporal synthetic prompt');
   await finish(page,'editor-input-'+width,['prompt','nav']);
   await page.screenshot({path:(process.env.QA_EVIDENCE_DIR||'evidence/round3/dynamic')+'/editor-'+width+'.png'});
   page.once('dialog',d=>d.accept());await page.goto('/assessments');
 }
 expect(errors).toEqual([]);
});
`;
fs.writeFileSync('tests/expanded-appearance-browser/editor-temporal.spec.ts',b);
let s=fs.readFileSync('tests/receipt-ui-browser/receipt.spec.ts','utf8');
s=s.slice(0,s.indexOf("  await post(lessonBase + '/draft',"));
s=s.replace("import AxeBuilder from '@axe-core/playwright';", "import AxeBuilder from '@axe-core/playwright';\nimport {install,start,finish} from './temporal-helper';");
s=s.replace("test('shared receipt preserves immutable history, grading, appeals and role boundaries'", "test('responsive lesson and receipt painted controls across data and intra-view transitions'");
s+=`
 await page.goto('/dashboard');
 await page.locator('summary:visible').filter({hasText:'Theme'}).click();
 const saved=page.waitForResponse(r=>r.url().includes('/api/branding/preference')&&r.request().method()==='POST');
 await page.getByRole('button',{name:'Dark',exact:true}).click();await saved;
 await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
 await install(page);
 for(const width of [1440,820,390]){
   await page.setViewportSize({width,height:1000});
   let open!:()=>void;const gate=new Promise<void>(r=>open=r);let seen=false;
   const pattern='**/api'+lessonBase+'?*';
   await page.route(pattern,async r=>{seen=true;await gate;await r.continue();});
   await page.goto('/enrolments/'+id+'/delivery/'+block+'/0');
   await expect.poll(()=>seen).toBe(true);await expect(page.getByText('Loading lesson...',{exact:true})).toBeVisible();
   await page.getByRole('link',{name:'Back to learning plan',exact:true}).evaluate(e=>e.setAttribute('data-qa-back',''));
   await start(page,{back:'[data-qa-back]',response:'#work-body'},'lesson-pending-ready');
   open();await expect(page.getByLabel('Your response',{exact:true})).toBeVisible();
   await finish(page,'lesson-ready-'+width,['back']);await page.unroute(pattern);
   await page.getByLabel('Your response',{exact:true}).scrollIntoViewIfNeeded();
   await start(page,{response:'#work-body'},'lesson-draft');
   await page.getByLabel('Your response',{exact:true}).fill('Temporal response '+width);
   await expect(page.getByText('Draft saved. This has not been submitted.',{exact:true})).toBeVisible();
   await finish(page,'lesson-autosave-'+width,['response']);
   await page.screenshot({path:(process.env.QA_EVIDENCE_DIR||'evidence/round3/dynamic')+'/lesson-'+width+'.png'});
 }
 const current=await (await page.request.get('/api'+lessonBase+'?clientId='+client)).json();
 const first=await post(lessonBase+'/submit',{clientId:client,version:current.draft.version,key:crypto.randomUUID()});
 const receiptUrl='/enrolments/'+id+'/submissions/'+first.id;
 for(const width of [1440,820,390]){
   await page.setViewportSize({width,height:1000});
   let open!:()=>void;const gate=new Promise<void>(r=>open=r);let seen=false;
   const pattern='**/api'+receiptUrl+'?*';
   await page.route(pattern,async r=>{seen=true;await gate;await r.continue();});
   await page.goto(receiptUrl);await expect.poll(()=>seen).toBe(true);
   await expect(page.getByText('Loading submission receipt...',{exact:true})).toBeVisible();
   await page.getByRole('link',{name:'Back to learning plan',exact:true}).evaluate(e=>e.setAttribute('data-qa-back',''));
   await start(page,{back:'[data-qa-back]'},'receipt-pending-ready');open();
   await expect(page.getByText('Status: submitted',{exact:true})).toBeVisible();
   await finish(page,'receipt-ready-'+width,['back']);await page.unroute(pattern);
   await page.getByRole('heading',{name:'Attempt 1',exact:true}).evaluate(e=>e.setAttribute('data-qa-attempt',''));
   await page.getByText('Receipt integrity and rubric',{exact:true}).scrollIntoViewIfNeeded();
   await page.getByText('Receipt integrity and rubric',{exact:true}).evaluate(e=>e.setAttribute('data-qa-integrity',''));
   await start(page,{integrity:'[data-qa-integrity]'},'receipt-integrity-expand');
   await page.getByText('Receipt integrity and rubric',{exact:true}).click();
   await finish(page,'receipt-details-'+width,['integrity']);
   await page.screenshot({path:(process.env.QA_EVIDENCE_DIR||'evidence/round3/dynamic')+'/receipt-'+width+'.png'});
 }
 expect(errors).toEqual([]);
});
`;
fs.writeFileSync('tests/expanded-appearance-browser/learning-temporal.spec.ts',s);
