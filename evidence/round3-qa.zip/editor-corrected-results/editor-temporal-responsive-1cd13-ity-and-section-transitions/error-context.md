# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor-temporal.spec.ts >> responsive editor controls through authority and section transitions
- Location: tests\expanded-appearance-browser\editor-temporal.spec.ts:4:1

# Error details

```
Error: editor-input-1440 nav observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   0
```

```
Error: editor-input-390 nav observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1
```

# Page snapshot

```yaml
- generic [active] [ref=f6e1]:
  - link "Skip to content" [ref=f6e2] [cursor=pointer]:
    - /url: "#main"
  - alert [ref=f6e3]
  - main [ref=f6e5]:
    - generic [ref=f6e6]:
      - generic [ref=f6e7]:
        - heading "Opening workspace" [level=1] [ref=f6e8]
        - paragraph [ref=f6e9]: Waiting for this destination’s appearance.
      - status [ref=f6e11]: Loading appearance...
```

# Test source

```ts
  1  | import { expect, Page } from '@playwright/test';
  2  | import { mkdir, writeFile } from 'node:fs/promises';
  3  | export async function install(page: Page) {
  4  |   await page.addInitScript(() => {
  5  |     const w=window as any; w.__temporal={frames:[],selectors:{},phase:'initial'};
  6  |     const tick=()=>{ const s=w.__temporal; if(document.body) {
  7  |       const anchors:Record<string,unknown>={};
  8  |       for(const [name,selector] of Object.entries(s.selectors)) {
  9  |         const el=document.querySelector(selector as string) as HTMLElement|null;
  10 |         if(el && el.checkVisibility({checkVisibilityCSS:true,checkOpacity:true})) {
  11 |           const r=el.getBoundingClientRect(),css=getComputedStyle(el);
  12 |           if(r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight) anchors[name]={x:r.x,y:r.y+scrollY,width:r.width,height:r.height,font:css.font,color:css.color,background:css.backgroundColor};
  13 |         }
  14 |       }
  15 |       s.frames.push({t:performance.now(),phase:s.phase,theme:document.documentElement.dataset.theme,width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,anchors});
  16 |     } requestAnimationFrame(tick); };requestAnimationFrame(tick);
  17 |   });
  18 | }
  19 | export async function start(page:Page, selectors:Record<string,string>, phase:string) {
  20 |   await page.evaluate(({selectors,phase})=>{const s=(window as any).__temporal;s.frames=[];s.selectors=selectors;s.phase=phase;},{selectors,phase});
  21 | }
  22 | export async function finish(page:Page,label:string,required:string[]) {
  23 |   // Observe completed paints, not just the synchronous DOM assertion.
  24 |   await page.evaluate(()=>new Promise<void>(r=>{let n=8;function tick(){if(--n)requestAnimationFrame(tick);else r();}requestAnimationFrame(tick);}));
  25 |   const frames=await page.evaluate(()=>(window as any).__temporal.frames);
  26 |   const out=process.env.QA_EVIDENCE_DIR || 'evidence/round3/dynamic';await mkdir(out,{recursive:true});
  27 |   await writeFile(out+'/'+label+'.json',JSON.stringify(frames,null,2));
  28 |   expect.soft(frames.filter((f:any)=>f.theme!=='dark'),label+' Dark').toEqual([]);
  29 |   expect.soft(frames.filter((f:any)=>f.overflow>1),label+' overflow').toEqual([]);
> 30 |   for(const name of required){const visible=frames.filter((f:any)=>f.anchors[name]);expect.soft(visible.length,label+' '+name+' observed').toBeGreaterThan(1);
     |                                                                                                                                            ^ Error: editor-input-390 nav observed
  31 |     if(!visible.length)continue;const first=visible[0].anchors[name];
  32 |     const bad=visible.filter((f:any)=>Object.entries(first).some(([k,v])=> typeof v==='number'?Math.abs(f.anchors[name][k]-v)>1:f.anchors[name][k]!==v));
  33 |     expect.soft(bad,label+' '+name+' painted geometry/styles').toEqual([]);
  34 |   }
  35 | }
  36 | 
```