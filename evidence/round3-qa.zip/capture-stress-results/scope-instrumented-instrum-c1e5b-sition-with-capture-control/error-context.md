# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scope-instrumented.spec.ts >> instrument exact authority transition with capture control
- Location: tests\expanded-appearance-browser\scope-instrumented.spec.ts:5:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 120

- Array []
+ Array [
+   Object {
+     "bg": "#0c1218",
+     "bodyStyle": Object {
+       "display": "block",
+       "width": "1px",
+     },
+     "brand": "Local sandboxSynthetic people · Local password sign-in · No email deliverySScope QA ownerCurrent client access",
+     "capture": "settled",
+     "heading": "Welcome back, Scope QA owner.",
+     "mainStyle": Object {
+       "display": "block",
+       "padding": "8px 16px 24px",
+       "position": "static",
+       "width": "32px",
+     },
+     "path": "/dashboard",
+     "pending": false,
+     "rect": Object {
+       "width": 32,
+       "x": 0,
+       "y": 613,
+     },
+     "shell": "learning",
+     "styles": Array [
+       Object {
+         "disabled": false,
+         "href": "http://127.0.0.1:3110/_next/static/chunks/2n47il59nclm4.css",
+         "media": "",
+         "rules": 164,
+       },
+       Object {
+         "disabled": false,
+         "href": "http://127.0.0.1:3110/_next/static/chunks/0gvz6m3g5j5_c.css",
+         "media": "",
+         "rules": 804,
+       },
+     ],
+     "t": 1171.7000000476837,
+     "text": "Skip to content
+ Q
+ Workspace
+ Learning workspace
+ Local sandbox
+ S
+ Scope QA owner
+ Menu
+ Active client
+ Choose client
+ Demo Client 1
+ Demo Client 2
+ Demo Client 3
+ Switch client
+
+ Your development space
+
+ Welcome back, Scope QA owner.
+
+ A little focus today. A meaningful step forward.
+
+ The big picture
+
+ Your next chapter
+ starts with a baseline.
+
+ Understand your starting point, practise with purpose, and make your progress visible.
+
+ Your account
+ Client workspace
+ Name
+ Scope QA owner
+ Access
+ Scoped to the selected client
+ Learning plans
+ 0 plans
+ Workspace scope
+ Programmes in your scope
+ View learning plans
+ A focused journey
+ 01 / 03
+ 01
+ Know your starting point
+
+ Capture a baseline for your chosen skills.
+
+ 02
+ Put learning into practice
+
+ Turn weekly objectives into evidence.
+
+ 03
+ Reflect on your growth
+
+ Review your progress with approved evidence.
+
+ Training plans in your scope
+ 0 plans
+ No enrolments available
+
+ No training plans are currently available to you in this client. Contact your client administrator if you expected access.
+
+ Training records
+
+ Background receipts
+ Refreshes every 5 seconds
+
+ Local notification sink. No outbound email.
+
+ Loading your background receipts...
+
+ Scope QA",
+     "theme": "client-dark",
+     "viewport": Object {
+       "client": 1,
+       "height": 1,
+       "scroll": 0,
+       "width": 1,
+     },
+   },
+ ]
```

# Page snapshot

```yaml
- generic [active] [ref=f59e1]:
  - link "Skip to content" [ref=f59e2] [cursor=pointer]:
    - /url: "#main"
  - alert [ref=f59e3]
  - generic [ref=f59e4]:
    - complementary "Learning workspace" [ref=f59e5]:
      - link "QA Alpha — Overview" [ref=f59e6] [cursor=pointer]:
        - /url: /dashboard
        - generic [ref=f59e7]: Q
        - generic [ref=f59e8]:
          - strong [ref=f59e9]: QA Alpha
          - generic [ref=f59e10]: Scope QA
      - group [ref=f59e11]:
        - generic "Workspace Learning workspace" [ref=f59e12] [cursor=pointer]:
          - generic [ref=f59e15]:
            - generic [ref=f59e16]: Workspace
            - strong [ref=f59e17]: Learning workspace
      - paragraph [ref=f59e19]: Learning workspace
      - navigation "Main navigation" [ref=f59e20]:
        - link "Platform administration" [ref=f59e21] [cursor=pointer]:
          - /url: /platform
        - link "Overview" [ref=f59e28] [cursor=pointer]:
          - /url: /dashboard
        - link "Learning plans" [ref=f59e32] [cursor=pointer]:
          - /url: /dashboard#learning-plans
        - link "Assessments" [ref=f59e36] [cursor=pointer]:
          - /url: /assessments
        - link "Updates" [ref=f59e41] [cursor=pointer]:
          - /url: /notifications
        - link "People" [ref=f59e45] [cursor=pointer]:
          - /url: /people
        - link "Administration" [ref=f59e50] [cursor=pointer]:
          - /url: /administration
        - link "Account access" [ref=f59e57] [cursor=pointer]:
          - /url: /accounts
        - link "AI settings" [ref=f59e62] [cursor=pointer]:
          - /url: /settings/ai
        - link "Appearance" [ref=f59e66] [cursor=pointer]:
          - /url: /settings/appearance
        - link "Account security" [ref=f59e71] [cursor=pointer]:
          - /url: /account/security
      - generic [ref=f59e77]:
        - group [ref=f59e78]:
          - generic "Theme Client Dark" [ref=f59e79] [cursor=pointer]:
            - generic [ref=f59e81]: Theme
            - generic [ref=f59e82]: Client Dark
        - status [ref=f59e83]
    - generic [ref=f59e84]:
      - banner [ref=f59e85]:
        - generic [ref=f59e86]:
          - generic [ref=f59e87]: Local sandbox
          - generic [ref=f59e89]: Synthetic people · Local password sign-in · No email delivery
        - generic [ref=f59e90]:
          - button "Personal settings" [ref=f59e91] [cursor=pointer]: S
          - generic [ref=f59e92]:
            - strong [ref=f59e93]: Scope QA owner
            - generic [ref=f59e94]: Current client access
          - button "Sign out" [ref=f59e95] [cursor=pointer]
      - form "Active client" [ref=f59e98]:
        - generic [ref=f59e100]:
          - combobox "Active client" [ref=f59e101]:
            - option "Choose client"
            - option "Demo Client 1" [selected]
            - option "Demo Client 2"
            - option "Demo Client 3"
          - button "Switch client" [ref=f59e102] [cursor=pointer]
      - main [ref=f59e103]:
        - generic [ref=f59e104]:
          - generic [ref=f59e105]:
            - generic [ref=f59e106]:
              - paragraph [ref=f59e107]: Your development space
              - generic [ref=f59e108]:
                - heading "Welcome back, Scope QA owner." [level=1] [ref=f59e109]
                - paragraph [ref=f59e110]: A little focus today. A meaningful step forward.
            - generic [ref=f59e111]: Signed in
          - region "Your next chapter starts with a baseline." [ref=f59e112]:
            - generic [ref=f59e113]:
              - paragraph [ref=f59e114]: The big picture
              - heading "Your next chapter starts with a baseline." [level=2] [ref=f59e115]: Your next chapterstarts with a baseline.
              - paragraph [ref=f59e116]: Understand your starting point, practise with purpose, and make your progress visible.
          - generic [ref=f59e117]:
            - region "Your account" [ref=f59e118]:
              - generic [ref=f59e119]:
                - heading "Your account" [level=2] [ref=f59e120]
                - generic [ref=f59e121]: Client workspace
              - generic [ref=f59e122]:
                - generic [ref=f59e123]:
                  - term [ref=f59e124]: Name
                  - definition [ref=f59e125]: Scope QA owner
                - generic [ref=f59e126]:
                  - term [ref=f59e127]: Access
                  - definition [ref=f59e128]: Scoped to the selected client
                - generic [ref=f59e129]:
                  - term [ref=f59e130]: Learning plans
                  - definition [ref=f59e131]: 0 plans
                - generic [ref=f59e132]:
                  - term [ref=f59e133]: Workspace scope
                  - definition [ref=f59e134]: Programmes in your scope
              - link "View learning plans" [ref=f59e135] [cursor=pointer]:
                - /url: "#learning-plans"
            - region "A focused journey" [ref=f59e138]:
              - generic [ref=f59e139]:
                - heading "A focused journey" [level=2] [ref=f59e140]
                - generic [ref=f59e141]: 01 / 03
              - list [ref=f59e142]:
                - listitem [ref=f59e143]:
                  - generic [ref=f59e144]: "01"
                  - generic [ref=f59e145]:
                    - heading "Know your starting point" [level=3] [ref=f59e146]
                    - paragraph [ref=f59e147]: Capture a baseline for your chosen skills.
                - listitem [ref=f59e148]:
                  - generic [ref=f59e149]: "02"
                  - generic [ref=f59e150]:
                    - heading "Put learning into practice" [level=3] [ref=f59e151]
                    - paragraph [ref=f59e152]: Turn weekly objectives into evidence.
                - listitem [ref=f59e153]:
                  - generic [ref=f59e154]: "03"
                  - generic [ref=f59e155]:
                    - heading "Reflect on your growth" [level=3] [ref=f59e156]
                    - paragraph [ref=f59e157]: Review your progress with approved evidence.
          - generic [ref=f59e158]:
            - heading "Training plans in your scope" [level=2] [ref=f59e159]
            - generic [ref=f59e162]: 0 plans
          - generic [ref=f59e164]:
            - heading "No enrolments available" [level=3] [ref=f59e167]
            - paragraph [ref=f59e168]: No training plans are currently available to you in this client. Contact your client administrator if you expected access.
          - paragraph [ref=f59e169]:
            - link "Training records" [ref=f59e170] [cursor=pointer]:
              - /url: /enrolments
          - region "Background check receipts" [ref=f59e171]:
            - generic [ref=f59e172]:
              - heading "Background receipts" [level=2] [ref=f59e173]
              - generic [ref=f59e174]: Refreshes every 5 seconds
            - paragraph [ref=f59e175]: Local notification sink. No outbound email.
            - list [ref=f59e176]:
              - listitem [ref=f59e177]: No checks requested yet. Open a training record to check background processing.
      - contentinfo [ref=f59e178]:
        - generic [ref=f59e179]: Scope QA
        - generic [ref=f59e180]: Learning with purpose. Progress with evidence.
```

# Test source

```ts
  36  |     await post('/clients/select', { clientId: client.id });
  37  |     const read = await page.request.get('/api/branding?clientId=' + client.id);
  38  |     expect(read.ok(), await read.text()).toBe(true);
  39  |     const brand = await read.json();
  40  |     await post('/branding', {
  41  |       clientId: client.id,
  42  |       version: brand.version,
  43  |       displayName: name,
  44  |       appName: 'Scope QA',
  45  |       accent,
  46  |       mode: 'white-label',
  47  |       theme,
  48  |       reason: 'Synthetic local scope verification',
  49  |     });
  50  |   }
  51  |   await post('/clients/select', { clientId: a.id });
  52  |   await page.addInitScript(() => {
  53  |     const w = window as any;
  54  |     w.__frames = []; w.__events = [];
  55  |     new MutationObserver(ms => { for(const m of ms) if(m.type==='attributes' || [...m.addedNodes,...m.removedNodes].some(n=>n instanceof HTMLStyleElement || n instanceof HTMLLinkElement)) w.__events.push({t:performance.now(),type:m.type,target:(m.target as Element).tagName,attribute:m.attributeName,old:m.oldValue,html:(m.target as Element).outerHTML?.slice(0,2000)}); }).observe(document,{subtree:true,childList:true,attributes:true,attributeOldValue:true,attributeFilter:['style','media','disabled']});
  56  |     new PerformanceObserver(list => {for(const e of list.getEntries()) w.__events.push({type:e.entryType,t:e.startTime,value:(e as any).value,sources:(e as any).sources?.map((s:any)=>({node:s.node?.outerHTML?.slice(0,300),previous:s.previousRect,current:s.currentRect}))});}).observe({type:'layout-shift',buffered:true});
  57  |     const record = () => {
  58  |       if (document.body) {
  59  |         const main = document.querySelector('main'),
  60  |           r = main?.getBoundingClientRect();
  61  |         w.__frames.push({
  62  |           t: performance.now(),
  63  |           viewport:{width:innerWidth,height:innerHeight,client:document.documentElement.clientWidth,scroll:scrollY},
  64  |           capture:w.__capture || null,
  65  |           mainStyle:main?{display:getComputedStyle(main).display,width:getComputedStyle(main).width,padding:getComputedStyle(main).padding,position:getComputedStyle(main).position}:null,
  66  |           bodyStyle:{display:getComputedStyle(document.body).display,width:getComputedStyle(document.body).width},
  67  |           styles:[...document.styleSheets].map(s=>({href:s.href,disabled:s.disabled,media:s.media.mediaText,rules:(()=>{try{return s.cssRules.length}catch{return -1}})()})),
  68  |           brand:document.querySelector('[data-application-shell] header')?.textContent,
  69  |           path: location.pathname,
  70  |           theme: document.documentElement.dataset.theme,
  71  |           bg: getComputedStyle(document.documentElement).getPropertyValue('--bg').trim(),
  72  |           heading: document.querySelector('main h1')?.textContent,
  73  |           pending: Boolean(document.querySelector('[data-appearance-pending]')),
  74  |           text: document.body.innerText,
  75  |           shell: document
  76  |             .querySelector('[data-application-shell]')
  77  |             ?.getAttribute('data-application-shell'),
  78  |           rect: r ? { x: r.x, y: r.y, width: r.width } : null,
  79  |         });
  80  |       }
  81  |       requestAnimationFrame(record);
  82  |     };
  83  |     requestAnimationFrame(record);
  84  |   });
  85  |   for(let iteration=0;iteration<60;iteration++){
  86  |   const dir=(process.env.QA_EVIDENCE_DIR || 'evidence/round3/scope')+'/'+iteration; await mkdir(dir,{recursive:true});
  87  |   await page.goto('/platform');
  88  |   await expect(page.getByRole('heading', { name: 'Platform overview', exact: true })).toBeVisible();
  89  |   await page.locator('summary:visible').filter({ hasText: 'Theme' }).click();
  90  |   await page.getByRole('button', { name: 'Light', exact: true }).click();
  91  |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  92  |   await page.locator('summary').filter({ hasText: 'Workspace' }).click();
  93  |   let release!: () => void;
  94  |   const held = new Promise<void>((r) => (release = r));
  95  |   let requested!: () => void;
  96  |   const seen = new Promise<void>((r) => (requested = r));
  97  |   await page.route('**/api/branding/current?shared=0', async (route) => {
  98  |     requested();
  99  |     await held;
  100 |     await route.continue();
  101 |   });
  102 |   await page.evaluate(() => {
  103 |     (window as any).__frames = [];
  104 |   });
  105 |   await page.getByRole('link', { name: 'Learning workspace', exact: true }).click();
  106 |   await seen;
  107 |   await page.waitForTimeout(150);
  108 |   await expect.soft(page.locator('[data-appearance-pending]')).toBeVisible();
  109 |   await expect
  110 |     .soft(page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true }))
  111 |     .not.toBeVisible();
  112 |   const pending = await page.evaluate(() => ({
  113 |     theme: document.documentElement.dataset.theme,
  114 |     heading: document.querySelector('main h1')?.textContent,
  115 |     frames: (window as any).__frames,
  116 |   }));
  117 |   if(capture){ await page.evaluate(()=>{(window as any).__capture='pending';}); await page.screenshot({ path: dir + '/scope-client-pending.png', fullPage: true }); await page.evaluate(()=>{(window as any).__capture=null;}); }
  118 |   release();
  119 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'client-dark');
  120 |   await expect(
  121 |     page.getByRole('heading', { name: 'Welcome back, Scope QA owner.', exact: true }),
  122 |   ).toBeVisible();
  123 |   if(capture){ await page.evaluate(()=>{(window as any).__capture='settled';}); await page.screenshot({ path: dir + '/scope-client-settled.png', fullPage: true }); await page.evaluate(()=>{(window as any).__capture=null;}); }
  124 |   await page.waitForTimeout(300);
  125 |   await writeFile(dir+'/events.json',JSON.stringify(await page.evaluate(()=>(window as any).__events),null,2));
  126 |   const frames = await page.evaluate(() => (window as any).__frames);
  127 |   await writeFile(dir + '/scope-transition.json', JSON.stringify({ pending, frames }, null, 2));
  128 |   expect
  129 |     .soft(
  130 |       frames.filter(
  131 |         (f: any) =>
  132 |           f.heading === 'Welcome back, Scope QA owner.' &&
  133 |           (f.theme !== 'client-dark' || !f.text.includes('QA Alpha')),
  134 |       ),
  135 |     )
> 136 |     .toEqual([]);
      |      ^ Error: expect(received).toEqual(expected) // deep equality
  137 |   expect
  138 |     .soft(frames.filter((f: any) => f.path === '/dashboard' && !f.shell && !f.pending))
  139 |     .toEqual([]);
  140 |   await page.unroute('**/api/branding/current?shared=0');
  141 |   }
  142 | 
  143 | });
  144 | 
```