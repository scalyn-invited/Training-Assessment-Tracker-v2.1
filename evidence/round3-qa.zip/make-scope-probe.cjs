const fs=require('fs');
let s=fs.readFileSync('tests/expanded-appearance-browser/scope.spec.ts','utf8');
s=s.slice(0,s.indexOf('  const transition = async'))+'\n});\n';
s=s.replace("const dir = process.env.QA_EVIDENCE_DIR || 'evidence/expanded';", "const dir = process.env.QA_EVIDENCE_DIR || 'evidence/round3/scope';\nconst capture = process.env.QA_CAPTURE !== '0';");
s=s.replace('    w.__frames = [];', `    w.__frames = []; w.__events = [];
    new MutationObserver(ms => { for(const m of ms) if(m.type==='attributes' || [...m.addedNodes,...m.removedNodes].some(n=>n instanceof HTMLStyleElement || n instanceof HTMLLinkElement)) w.__events.push({t:performance.now(),type:m.type,target:(m.target as Element).tagName,attribute:m.attributeName,old:m.oldValue,html:(m.target as Element).outerHTML?.slice(0,2000)}); }).observe(document,{subtree:true,childList:true,attributes:true,attributeOldValue:true,attributeFilter:['style','media','disabled']});
    new PerformanceObserver(list => {for(const e of list.getEntries()) w.__events.push({type:e.entryType,t:e.startTime,value:(e as any).value,sources:(e as any).sources?.map((s:any)=>({node:s.node?.outerHTML?.slice(0,300),previous:s.previousRect,current:s.currentRect}))});}).observe({type:'layout-shift',buffered:true});`);
s=s.replace('          t: performance.now(),', `          t: performance.now(),
          viewport:{width:innerWidth,height:innerHeight,client:document.documentElement.clientWidth,scroll:scrollY},
          capture:w.__capture || null,
          mainStyle:main?{display:getComputedStyle(main).display,width:getComputedStyle(main).width,padding:getComputedStyle(main).padding,position:getComputedStyle(main).position}:null,
          bodyStyle:{display:getComputedStyle(document.body).display,width:getComputedStyle(document.body).width},
          styles:[...document.styleSheets].map(s=>({href:s.href,disabled:s.disabled,media:s.media.mediaText,rules:(()=>{try{return s.cssRules.length}catch{return -1}})()})),
          brand:document.querySelector('[data-application-shell] header')?.textContent,`);
s=s.replace("  await page.screenshot({ path: dir + '/scope-client-pending.png', fullPage: true });", `  if(capture){ await page.evaluate(()=>{(window as any).__capture='pending';}); await page.screenshot({ path: dir + '/scope-client-pending.png', fullPage: process.env.QA_CAPTURE !== 'viewport' }); await page.evaluate(()=>{(window as any).__capture=null;}); }`);
s=s.replace("  await page.screenshot({ path: dir + '/scope-client-settled.png', fullPage: true });", `  if(capture){ await page.evaluate(()=>{(window as any).__capture='settled';}); await page.screenshot({ path: dir + '/scope-client-settled.png', fullPage: process.env.QA_CAPTURE !== 'viewport' }); await page.evaluate(()=>{(window as any).__capture=null;}); }
  await page.waitForTimeout(300);
  await writeFile(dir+'/events.json',JSON.stringify(await page.evaluate(()=>(window as any).__events),null,2));`);
s=s.replace("test('real API scoped navigation never renders target content in the previous scope theme'", "test('instrument exact authority transition with capture control'");
s=s.replace("  await page.goto('/platform');", "  for(let iteration=0;iteration<60;iteration++){\n  const dir=(process.env.QA_EVIDENCE_DIR || 'evidence/round3/scope')+'/'+iteration; await mkdir(dir,{recursive:true});\n  await page.goto('/platform');");
s=s.replace("  await page.unroute('**/api/branding/current?shared=0');", "  await page.unroute('**/api/branding/current?shared=0');\n  }");
fs.writeFileSync('tests/expanded-appearance-browser/scope-instrumented.spec.ts',s);
