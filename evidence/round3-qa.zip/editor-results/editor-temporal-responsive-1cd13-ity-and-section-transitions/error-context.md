# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor-temporal.spec.ts >> responsive editor controls through authority and section transitions
- Location: tests\expanded-appearance-browser\editor-temporal.spec.ts:4:1

# Error details

```
Error: editor-questions-1440 nav painted geometry/styles

expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 299

- Array []
+ Array [
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1200.3999999761581,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1203.3999999761581,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1218.3000000715256,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1369.5,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1384.8000000715256,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1401.3999999761581,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1418.3000000715256,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1435,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1451.5,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1468.2000000476837,
+     "theme": "dark",
+     "width": 1440,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 423.359375,
+         "y": 565,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 1249.3125,
+         "y": 275.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1485,
+     "theme": "dark",
+     "width": 1440,
+   },
+ ]
```

```
Error: editor-input-1440 nav observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1
```

```
Error: editor-questions-820 nav painted geometry/styles

expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 299

- Array []
+ Array [
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1094.9000000953674,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1106.4000000953674,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1123.5,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1138.8000000715256,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1155.6000000238419,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1172.3000000715256,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1189.1000000238419,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1205.6000000238419,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1222.2000000476837,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1239.2000000476837,
+     "theme": "dark",
+     "width": 820,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 112.203125,
+         "x": 387.359375,
+         "y": 657.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 89.6875,
+         "x": 430.34375,
+         "y": 506.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1255.7000000476837,
+     "theme": "dark",
+     "width": 820,
+   },
+ ]
```

```
Error: editor-input-820 nav observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1
```

```
Error: editor-ready-390 title observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   0
```

```
Error: editor-questions-390 nav painted geometry/styles

expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 272

- Array []
+ Array [
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1088.5,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1101.7999999523163,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1118.6000000238419,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1135.7999999523163,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1151.6000000238419,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1168.1999999284744,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1185,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1201.8999999761581,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1221.2999999523163,
+     "theme": "dark",
+     "width": 390,
+   },
+   Object {
+     "anchors": Object {
+       "nav": Object {
+         "background": "rgb(22, 33, 61)",
+         "color": "rgb(233, 237, 247)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 175,
+         "x": 199,
+         "y": 839.5,
+       },
+       "save": Object {
+         "background": "rgb(47, 107, 235)",
+         "color": "rgb(255, 255, 255)",
+         "font": "500 13px / 18px Inter, \"Segoe UI\", sans-serif",
+         "height": 36,
+         "width": 158,
+         "x": 199,
+         "y": 675.5,
+       },
+     },
+     "overflow": 0,
+     "phase": "section-switch",
+     "t": 1234.8999999761581,
+     "theme": "dark",
+     "width": 390,
+   },
+ ]
```

```
Error: editor-input-390 nav observed

expect(received).toBeGreaterThan(expected)

Expected: > 1
Received:   1
```

# Page snapshot

```yaml
- generic [active] [ref=f6e1]:
  - link "Skip to content" [ref=f6e2] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f6e3]:
    - banner [ref=f6e4]:
      - link [ref=f6e5] [cursor=pointer]:
        - /url: /login
        - strong [ref=f6e7]: Scalyn
    - generic [ref=f6e8]:
      - generic [ref=f6e10]:
        - group [ref=f6e11]:
          - generic "Theme" [ref=f6e12] [cursor=pointer]
        - status [ref=f6e16]
      - main [ref=f6e17]:
        - generic [ref=f6e18]:
          - heading "Assessments" [level=1] [ref=f6e20]
          - status [ref=f6e21]: Loading your session...
  - alert [ref=f6e22]
```

# Test source

```ts
  1  | import { expect, Page } from '@playwright/test';
  2  | import { mkdir, writeFile } from 'node:fs/promises';
  3  | export async function install(page: Page) {
  4  |   await page.addInitScript(() => {
  5  |     const w=window as any; w.__temporal={frames:[],selectors:{},phase:'initial'};
  6  |     const tick=()=>{ const s=w.__temporal; if(document.body) {
  7  |       const anchors:Record<string,unknown>={};
  8  |       for(const [name,selector] of Object.entries(s.selectors)) {
  9  |         const el=document.querySelector(selector as string) as HTMLElement|null;
  10 |         if(el && el.checkVisibility({checkVisibilityCSS:true,checkOpacity:true})) {
  11 |           const r=el.getBoundingClientRect(),css=getComputedStyle(el);
  12 |           if(r.width>0&&r.height>0&&r.bottom>0&&r.top<innerHeight) anchors[name]={x:r.x,y:r.y+scrollY,width:r.width,height:r.height,font:css.font,color:css.color,background:css.backgroundColor};
  13 |         }
  14 |       }
  15 |       s.frames.push({t:performance.now(),phase:s.phase,theme:document.documentElement.dataset.theme,width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,anchors});
  16 |     } requestAnimationFrame(tick); };requestAnimationFrame(tick);
  17 |   });
  18 | }
  19 | export async function start(page:Page, selectors:Record<string,string>, phase:string) {
  20 |   await page.evaluate(({selectors,phase})=>{const s=(window as any).__temporal;s.frames=[];s.selectors=selectors;s.phase=phase;},{selectors,phase});
  21 | }
  22 | export async function finish(page:Page,label:string,required:string[]) {
  23 |   // Observe completed paints, not just the synchronous DOM assertion.
  24 |   await page.evaluate(()=>new Promise<void>(r=>{let n=8;function tick(){if(--n)requestAnimationFrame(tick);else r();}requestAnimationFrame(tick);}));
  25 |   const frames=await page.evaluate(()=>(window as any).__temporal.frames);
  26 |   const out=process.env.QA_EVIDENCE_DIR || 'evidence/round3/dynamic';await mkdir(out,{recursive:true});
  27 |   await writeFile(out+'/'+label+'.json',JSON.stringify(frames,null,2));
  28 |   expect.soft(frames.filter((f:any)=>f.theme!=='dark'),label+' Dark').toEqual([]);
  29 |   expect.soft(frames.filter((f:any)=>f.overflow>1),label+' overflow').toEqual([]);
> 30 |   for(const name of required){const visible=frames.filter((f:any)=>f.anchors[name]);expect.soft(visible.length,label+' '+name+' observed').toBeGreaterThan(1);
     |                                                                                                                                            ^ Error: editor-input-390 nav observed
  31 |     if(!visible.length)continue;const first=visible[0].anchors[name];
  32 |     const bad=visible.filter((f:any)=>Object.entries(first).some(([k,v])=> typeof v==='number'?Math.abs(f.anchors[name][k]-v)>1:f.anchors[name][k]!==v));
  33 |     expect.soft(bad,label+' '+name+' painted geometry/styles').toEqual([]);
  34 |   }
  35 | }
  36 | 
```